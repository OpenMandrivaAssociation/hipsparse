/*! \file */
/* ************************************************************************
* Copyright (C) 2025-2026 Advanced Micro Devices, Inc. All rights Reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
* AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
* LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
* OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
* THE SOFTWARE.
*
* ************************************************************************ */
#pragma once

#include "hipsparse_test.hpp"
#include "hipsparse_test_dispatch_enum.hpp"
#include "hipsparse_type_dispatch.hpp"

template <hipsparse_test_dispatch_enum::value_type TYPE_DISPATCH = hipsparse_test_dispatch_enum::t>
struct hipsparse_test_dispatch;

template <>
struct hipsparse_test_dispatch<hipsparse_test_dispatch_enum::t>
{
    template <template <typename...> class TEST>
    static auto dispatch(const Arguments& arg)
    {
        return hipsparse_simple_dispatch<TEST>(arg);
    }
};

template <>
struct hipsparse_test_dispatch<hipsparse_test_dispatch_enum::it>
{
    template <template <typename...> class TEST>
    static auto dispatch(const Arguments& arg)
    {
        return hipsparse_it_dispatch<TEST>(arg);
    }
};

template <>
struct hipsparse_test_dispatch<hipsparse_test_dispatch_enum::ijt>
{
    template <template <typename...> class TEST>
    static auto dispatch(const Arguments& arg)
    {
        return hipsparse_ijt_dispatch<TEST>(arg);
    }
};

template <>
struct hipsparse_test_dispatch<hipsparse_test_dispatch_enum::scatter>
{
    template <template <typename...> class TEST>
    static auto dispatch(const Arguments& arg)
    {
        return hipsparse_scatter_dispatch<TEST>(arg);
    }
};

template <>
struct hipsparse_test_dispatch<hipsparse_test_dispatch_enum::gather>
{
    template <template <typename...> class TEST>
    static auto dispatch(const Arguments& arg)
    {
        return hipsparse_gather_dispatch<TEST>(arg);
    }
};

template <>
struct hipsparse_test_dispatch<hipsparse_test_dispatch_enum::axpby>
{
    template <template <typename...> class TEST>
    static auto dispatch(const Arguments& arg)
    {
        return hipsparse_axpby_dispatch<TEST>(arg);
    }
};

template <>
struct hipsparse_test_dispatch<hipsparse_test_dispatch_enum::spvv>
{
    template <template <typename...> class TEST>
    static auto dispatch(const Arguments& arg)
    {
        return hipsparse_spvv_dispatch<TEST>(arg);
    }
};

template <>
struct hipsparse_test_dispatch<hipsparse_test_dispatch_enum::ijabct_spmv>
{
    template <template <typename...> class TEST>
    static auto dispatch(const Arguments& arg)
    {
        return hipsparse_ijabct_spmv_dispatch<TEST>(arg);
    }
};

template <>
struct hipsparse_test_dispatch<hipsparse_test_dispatch_enum::iabct_spmv>
{
    template <template <typename...> class TEST>
    static auto dispatch(const Arguments& arg)
    {
        return hipsparse_iabct_spmv_dispatch<TEST>(arg);
    }
};