/* ************************************************************************
 * Copyright (C) 2021-2026 Advanced Micro Devices, Inc. All rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 *
 * ************************************************************************ */

#include "test.hpp"
#include "testing_spsm_csr.hpp"
#include "testing_spsm_ex_csr.hpp"

TEST_ROUTINE_WITH_CONFIG(spsm_csr,
                         generic,
                         hipsparse_test_config_ijt,
                         arg.M,
                         arg.N,
                         arg.K,
                         arg.alpha,
                         arg.alphai,
                         arg.transA,
                         arg.transB,
                         arg.orderB,
                         arg.orderC,
                         arg.diag_type,
                         arg.fill_mode,
                         arg.baseA,
                         arg.spsm_alg);

TEST_ROUTINE_WITH_CONFIG(spsm_ex_csr,
                         generic,
                         hipsparse_test_config_ijt,
                         arg.M,
                         arg.N,
                         arg.K,
                         arg.alpha,
                         arg.alphai,
                         arg.transA,
                         arg.transB,
                         arg.orderB,
                         arg.orderC,
                         arg.diag_type,
                         arg.fill_mode,
                         arg.baseA,
                         arg.spsm_alg);
